chrome.devtools.panels.create("Custom commands", "icon_48.png", "logins.html", function() {});
